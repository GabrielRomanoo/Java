/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicoes;

/**
 *
 * @author ferauche
 */
public class UrnaException extends Exception {
    
    public UrnaException(String msg) {
        super(msg);
    }
    
}
